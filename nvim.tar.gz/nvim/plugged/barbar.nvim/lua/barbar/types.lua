--- @meta

--- @alias align side|'center'
--- @alias side 'left'|'right'
