return require('barbar.events')
