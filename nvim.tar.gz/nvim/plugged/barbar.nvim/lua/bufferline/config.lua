return require('barbar.config')
