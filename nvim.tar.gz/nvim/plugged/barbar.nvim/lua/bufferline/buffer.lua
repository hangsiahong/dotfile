return require('barbar.buffer')
