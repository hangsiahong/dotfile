# Steal my focus window
Gnome Shell Extension that removes the 'window is ready' message and focuses the window instead.  
This is a fork of the 'Steal My Focus' extension to add GNOME 45 support.

## Install
This extension is available on [GNOME Extensions Website](https://extensions.gnome.org/extension/6385/steal-my-focus-window/).
